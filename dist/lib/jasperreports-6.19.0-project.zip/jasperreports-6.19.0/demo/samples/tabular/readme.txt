
You need to have the Apache Ant build tool correctly installed on your system
and the Apache Ivy dependency management plugin installed in Ant, to easily run 
this sample application. 

The Apache Ant build tool can be downloaded from this location:
http://ant.apache.org/
The Apache Ivy dependency management plugin can be downloaded from this location:
http://ant.apache.org/ivy/

Please follow their installing instructions to have Apache Ant and Apache Ivy 
working on your system before trying our sample application.

Once you have them installed, launch "ant -p" from the command line in this directory
to learn more about what tasks you could run to build and test the sample.
